<div class="progress striped active bar">
	<div class="bar" style="width: <?php echo $percent; ?>%"></div>
</div>